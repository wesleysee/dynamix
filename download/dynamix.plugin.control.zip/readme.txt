Copy the PLG to the directory /boot/config/plugins on your unRAID server.

Issue the command: installplg /boot/config/plugins/dynamix.plugin.control-2.0.1-noarch-bergware.plg
