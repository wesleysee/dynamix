Copy the PLG to the directory /boot/plugins on your unRAID server.

Issue the command: installplg /boot/plugins/dynamix.webGui-2.1.0-noarch-bergware.plg
