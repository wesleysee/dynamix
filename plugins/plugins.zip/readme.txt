Choose the optional plugins you want to use and copy these to the directory /boot/config/plugins on your unRAID server.

Issue the command: installplg /boot/config/plugins/<name-of-the-plugin>.plg

Do the above for each optional plugin you want to install.
